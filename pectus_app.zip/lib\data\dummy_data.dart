import '../models/exercise_model.dart';

final List<Exercise> dummyExercises = [
  Exercise(
    id: '1',
    title: 'Vacuum Breathing',
    description: 'Deep breathing exercise to expand the rib cage and strengthen diaphragm.',
    instructions: '1. Stand or sit straight.\n2. Exhale completely.\n3. Pull your belly button in and up.\n4. Hold for 10-15 seconds.\n5. Release and inhale deeply.',
    benefits: 'Improves chest expansion and trains core muscles to hold the ribs in a better position.',
    durationSeconds: 180,
    category: ExerciseCategory.breathing,
  ),
  Exercise(
    id: '2',
    title: 'Doorway Stretch',
    description: 'Stretches the chest muscles and helps correct forward shoulder posture.',
    instructions: '1. Stand in a doorway.\n2. Place forearms on the doorframe at a 90-degree angle.\n3. Lean forward gently until you feel a stretch in your chest.\n4. Hold for 30 seconds.',
    benefits: 'Opens up the chest, reduces tightness in pectoralis major/minor, and improves overall posture.',
    durationSeconds: 90,
    category: ExerciseCategory.flexibility,
  ),
  Exercise(
    id: '3',
    title: 'Dumbbell Pullover',
    description: 'A classic exercise for expanding the rib cage and building the chest.',
    instructions: '1. Lie your upper back across a flat bench.\n2. Hold a dumbbell with both hands above your chest.\n3. Lower the weight behind your head while keeping arms slightly bent.\n4. Pull it back up to the starting position.',
    benefits: 'Stretches the rib cage, builds the serratus anterior and chest muscles.',
    durationSeconds: 300,
    category: ExerciseCategory.strength,
  ),
  Exercise(
    id: '4',
    title: 'Wall Angels',
    description: 'Excellent for upper back strength and posture correction.',
    instructions: '1. Stand with back flat against a wall.\n2. Bring arms to 90 degrees against the wall.\n3. Slowly slide arms up and down the wall while keeping contact.\n4. Perform 15 repetitions.',
    benefits: 'Activates lower traps and rhomboids, combats rounded shoulders associated with Pectus.',
    durationSeconds: 120,
    category: ExerciseCategory.posture,
  ),
  Exercise(
    id: '5',
    title: 'Cat-Cow Stretch',
    description: 'Spinal mobility exercise to loosen the thoracic spine.',
    instructions: '1. Start on your hands and knees.\n2. Inhale and arch your back, dropping your belly (Cow).\n3. Exhale and round your spine upward (Cat).\n4. Repeat smoothly for 10-12 times.',
    benefits: 'Improves thoracic mobility which is crucial for overall chest expansion and posture.',
    durationSeconds: 60,
    category: ExerciseCategory.flexibility,
  ),
];
