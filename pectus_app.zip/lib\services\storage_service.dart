import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  int get completedSessions => _prefs?.getInt('completed_sessions') ?? 0;
  
  Future<void> incrementCompletedSessions() async {
    final current = completedSessions;
    await _prefs?.setInt('completed_sessions', current + 1);
  }

  int get streakDays => _prefs?.getInt('streak_days') ?? 0;

  Future<void> updateStreak() async {
    final lastWorkoutTimeStr = _prefs?.getString('last_workout_time');
    final now = DateTime.now();
    
    if (lastWorkoutTimeStr != null) {
      final lastWorkout = DateTime.parse(lastWorkoutTimeStr);
      final diff = now.difference(lastWorkout).inDays;
      
      if (diff == 1) {
        // Increment streak
        await _prefs?.setInt('streak_days', streakDays + 1);
      } else if (diff > 1) {
        // Reset streak
        await _prefs?.setInt('streak_days', 1);
      }
    } else {
      // First workout
      await _prefs?.setInt('streak_days', 1);
    }
    
    await _prefs?.setString('last_workout_time', now.toIso8601String());
  }
}
