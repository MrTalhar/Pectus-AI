import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/app_provider.dart';
import 'screens/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  final appProvider = AppProvider();
  await appProvider.init();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: appProvider),
      ],
      child: const PectusApp(),
    ),
  );
}

class PectusApp extends StatelessWidget {
  const PectusApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pectus Excavatum App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF111827),
        primaryColor: const Color(0xFFDC2626),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFDC2626),
          surface: Color(0xFF1F2937),
        ),
        textTheme: const TextTheme(
          bodyLarge: TextStyle(color: Color(0xFFF9FAFB)),
          bodyMedium: TextStyle(color: Color(0xFFF9FAFB)),
          labelLarge: TextStyle(color: Color(0xFF9CA3AF)),
        ),
        cardTheme: CardTheme(
          color: const Color(0xFF1F2937),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF111827),
          elevation: 0,
          centerTitle: true,
        ),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}
