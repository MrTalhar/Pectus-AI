class Exercise {
  final String id;
  final String title;
  final String description;
  final String instructions;
  final String benefits;
  final int durationSeconds;
  final ExerciseCategory category;
  
  Exercise({
    required this.id,
    required this.title,
    required this.description,
    required this.instructions,
    required this.benefits,
    required this.durationSeconds,
    required this.category,
  });
}

enum ExerciseCategory {
  breathing,
  posture,
  strength,
  flexibility
}

extension CategoryExtension on ExerciseCategory {
  String get name {
    switch (this) {
      case ExerciseCategory.breathing:
        return 'Breathing';
      case ExerciseCategory.posture:
        return 'Posture';
      case ExerciseCategory.strength:
        return 'Strength';
      case ExerciseCategory.flexibility:
        return 'Flexibility';
    }
  }
}
