import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';
import '../widgets/stat_card.dart';

class ProgressScreen extends StatelessWidget {
  const ProgressScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AppProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Progress'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Overview',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: StatCard(
                    title: 'Total Sessions',
                    value: '${provider.completedSessions}',
                    icon: Icons.fitness_center,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: StatCard(
                    title: 'Current Streak',
                    value: '${provider.streakDays}',
                    icon: Icons.local_fire_department,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 32),
            const Text(
              'Achievements',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 16),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              mainAxisSpacing: 16,
              crossAxisSpacing: 16,
              childAspectRatio: 1.2,
              children: [
                _buildBadgeCard(
                  context,
                  'First Step',
                  'Complete 1 session',
                  Icons.star,
                  provider.completedSessions >= 1,
                ),
                _buildBadgeCard(
                  context,
                  'Consistency',
                  '3 day streak',
                  Icons.trending_up,
                  provider.streakDays >= 3,
                ),
                _buildBadgeCard(
                  context,
                  'Dedication',
                  '10 total sessions',
                  Icons.emoji_events,
                  provider.completedSessions >= 10,
                ),
                _buildBadgeCard(
                  context,
                  'Iron Will',
                  '7 day streak',
                  Icons.diamond,
                  provider.streakDays >= 7,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBadgeCard(BuildContext context, String title, String subtitle, IconData icon, bool isUnlocked) {
    return Card(
      color: isUnlocked ? Theme.of(context).cardTheme.color : Theme.of(context).cardTheme.color?.withOpacity(0.5),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 40,
              color: isUnlocked ? const Color(0xFFFFD700) : Colors.grey[700],
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: isUnlocked ? Colors.white : Colors.grey[500],
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12,
                color: isUnlocked ? Colors.grey[400] : Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
