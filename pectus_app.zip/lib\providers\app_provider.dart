import 'package:flutter/foundation.dart';
import '../services/storage_service.dart';

class AppProvider with ChangeNotifier {
  final StorageService _storageService = StorageService();

  int get completedSessions => _storageService.completedSessions;
  int get streakDays => _storageService.streakDays;

  Future<void> init() async {
    await _storageService.init();
    notifyListeners();
  }

  Future<void> logSessionCompletion() async {
    await _storageService.incrementCompletedSessions();
    await _storageService.updateStreak();
    notifyListeners();
  }
}
